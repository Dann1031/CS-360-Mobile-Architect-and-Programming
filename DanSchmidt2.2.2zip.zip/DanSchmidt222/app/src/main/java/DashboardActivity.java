import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.danschmidt22.R;

public class DashboardActivity extends AppCompatActivity {

    private GridView gridView;
    private DBHelper dbHelper;
    private SimpleCursorAdapter cursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        gridView = findViewById(R.id.gridView);
        dbHelper = new DBHelper(this);

        Cursor cursor = dbHelper.getInventoryItems();
        cursorAdapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor,
                new String[]{COLUMN_ITEM_NAME, COLUMN_ITEM_QUANTITY},
                new int[]{R.id.itemName, R.id.itemQuantity}, 0);

        gridView.setAdapter(cursorAdapter);
    }
}

