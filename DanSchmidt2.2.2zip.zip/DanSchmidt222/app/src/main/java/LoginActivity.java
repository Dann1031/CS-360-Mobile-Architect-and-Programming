import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android. os. Bundle;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText username, password;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> createNewAccount());
    }

    private void loginUser() {
        String user = username.getText().toString();
        String pass = password.getText().toString();



        if (isUserValid(user, pass)) {

            Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isUserValid(String username, String password) {

        return true;  /
    }

    private void createNewAccount() {
        Intent intent = new Intent(LoginActivity.this, AccountCreationActivity.class);
        startActivity(intent);
    }
}
